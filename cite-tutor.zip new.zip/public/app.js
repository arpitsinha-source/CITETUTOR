const log = document.getElementById("log");
const form = document.getElementById("form");
const input = document.getElementById("q");
const sendBtn = document.getElementById("send");
const chatHistory = []; // previous Q/A pairs, sent back for follow-up questions

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

function addMessage(cls, html) {
  const div = document.createElement("div");
  div.className = "msg " + cls;
  div.innerHTML = html;
  log.appendChild(div);
  div.scrollIntoView({ behavior: "smooth", block: "end" });
  return div;
}

// Turns [cite:id] markers into numbered links and lists the sources below the answer.
function renderAnswer(answer, citations) {
  const byId = new Map(citations.map((c) => [c.id, c]));
  const order = [];
  const numberOf = new Map();

  const text = esc(answer).replace(/\[cite:([a-z0-9-]+)\]/gi, (_, id) => {
    if (!byId.has(id)) return ""; // drop any marker that doesn't match approved material
    if (!numberOf.has(id)) {
      order.push(id);
      numberOf.set(id, order.length);
    }
    const n = numberOf.get(id);
    return `<sup><a href="#src-${n}">[${n}]</a></sup>`;
  });

  let html = `<div>${text.replace(/\n/g, "<br>")}</div>`;

  if (order.length) {
    html += `<div class="sources"><strong>Sources</strong>`;
    order.forEach((id, i) => {
      const c = byId.get(id);
      html += `<details id="src-${i + 1}">
        <summary>[${i + 1}] ${esc(c.source)} — ${esc(c.section)}</summary>
        <blockquote>${esc(c.text)}</blockquote>
      </details>`;
    });
    html += `</div>`;
  }
  return html;
}

function autosize() {
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 140) + "px";
}

input.addEventListener("input", autosize);
input.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    form.requestSubmit();
  }
});

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const question = input.value.trim();
  if (!question) return;

  addMessage("user", esc(question));
  input.value = "";
  autosize();
  sendBtn.disabled = true;

  const pending = addMessage("bot", '<span class="hint">Searching approved material…</span>');

  try {
    const res = await fetch("/api/tutor", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ question, history: chatHistory.slice(-6) }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || "Request failed");

    pending.innerHTML = renderAnswer(data.answer, data.citations || []);
    chatHistory.push({ role: "user", content: question }, { role: "assistant", content: data.answer });
  } catch (err) {
    pending.className = "msg bot error";
    pending.textContent = "Sorry, something went wrong: " + err.message;
  } finally {
    sendBtn.disabled = false;
    input.focus();
  }
});
