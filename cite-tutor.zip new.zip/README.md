# Cite Tutor

An AI tutor that answers **only** from approved study material and shows a numbered citation for every claim.

## Folder structure

```
cite-tutor/
├── netlify.toml                  # Netlify build and routing config
├── public/
│   ├── index.html                # Chat UI
│   └── app.js                    # Front-end logic and citation rendering
└── netlify/
    └── functions/
        ├── tutor.js              # Serverless function: retrieval + AI call
        └── data/
            └── materials.json    # Approved study material (replace the sample)
```

## 1. Add your approved material

Edit `netlify/functions/data/materials.json`. Each item in `chunks` is one passage:

```json
{
  "id": "phy-ch3-02",
  "source": "Physics Class 11 Textbook, Ch. 3",
  "section": "3.2 Newton's second law",
  "text": "Paste the passage from the approved material here."
}
```

- `id`: unique, lowercase letters, digits and hyphens only. The tutor uses it for citations.
- `source`: book or document name, shown to students.
- `section`: chapter or section heading, shown to students.
- `text`: one passage, ideally one section or a few paragraphs.

The file ships with sample Biology content. Replace it before going live.

## 2. Deploy to Netlify

Recommended: push the folder to GitHub, then in Netlify choose **Add new site → Import an existing project** and select the repo. Netlify detects `netlify.toml` automatically.

Quick option: unzip the file, then drag the **unzipped folder** onto Netlify's deploy area.

## 3. Set the API key (required)

In Netlify: **Site configuration → Environment variables → Add a variable**

- Key: `ANTHROPIC_API_KEY`
- Value: your Anthropic API key

Optional: `TUTOR_MODEL` (defaults to `claude-haiku-5-5`).

Then trigger a new deploy (**Deploys → Trigger deploy**). Never put the API key in the front-end files.

## How it works

1. The student asks a question in the chat page.
2. `/api/tutor` (a Netlify Function) finds the relevant passages. If the whole material is small, it sends all of it.
3. The AI is instructed to answer only from those passages and to cite each claim as `[cite:id]`.
4. The page turns each citation into a numbered link and lists the source passages below the answer.
5. If the material does not cover the question, the tutor says so and gives no citation.

## Before a public launch

- Add rate limiting or sign-in, since each question costs API usage.
- Check that you have the right to use and display the study material.
- Test with several questions, including ones the material does not answer.
